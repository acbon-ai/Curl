<?php

$servername = "localhost";

$username = "store_admin";

$password = "password1#";

$dbname = "store_data";



$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {

  die("Connection failed: " . $conn->connect_error);

}

else {

    echo "connected succesfully"."<br/>";

}

$curl = curl_init('https://swapi.dev/api/planets');

if (!$curl) {

    die("Couldn't initialize a cURL handle");

};


curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$result = curl_exec($curl);


if (curl_errno($curl)) {

    echo (curl_error($curl));

    die();

};


curl_close($curl);

//Convert data into a JSON format, with Arrays



$response_data = json_decode($result, true);





//Print out the array format of the data from the Star Wars API



echo('<pre>');

print_r($response_data);

echo('</pre>');

echo('<br>');

foreach ($response_data as $row) {

    $query = "INSERT INTO starwars (Name, Rotation_period, Orbital_period, Diameter, Climate, Gravity, Terrain, Surface_water, Population, Created, Edited, Url) VALUES ('".$row["name"]."','".$row["rotation_period"]."','".$row["orbital_period"]."','".$row["diameter"]."','".$row["climate"]."','".$row["gravity"]."','".$row["terrain"]."','".$row["surface_water"]."','".$row["population"]."','".$row["created"]."','".$row["edited"]."','".$row["url"]."')";

    $conn->query($query);

    if ($conn->errno){

        echo($conn->error); die();}}


?>